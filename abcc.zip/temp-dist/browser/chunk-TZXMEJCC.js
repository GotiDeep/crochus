import{a as o}from"./chunk-4U675EIP.js";import{Ha as u,d as a,h as c,r as p,v as m}from"./chunk-3XQ2C4UZ.js";var I=(()=>{class r{constructor(){this.http=m(u)}submitOrder(t){return a(this,null,function*(){return c(this.http.post(`${o.apiUrl}/orders`,t))})}generateWhatsAppMessage(t){let n=t.items.map((e,i)=>`${i+1}. ${e.product.name} - INR ${e.product.price} (Qty: ${e.quantity})`).join(`
`),s=t.items.map((e,i)=>`${i+1}. ${o.siteUrl}/product/${e.product.slug}`).join(`
`);return`New Order - Crochus

Items Ordered:
${n}

Order Total: INR ${t.total.toLocaleString("en-IN")}

Customer Details:
Name: ${t.customer_name}
Phone: ${t.phone}
Address: ${t.address}
Pincode: ${t.pincode}
Note: ${t.note||"None"}

Product Links:
${s}`}openWhatsApp(t,n){try{let s=encodeURIComponent(t),e=`https://wa.me/${n}?text=${s}`;return window.open(e,"_blank"),!0}catch{return!1}}getOrderHistory(){return this.http.get(`${o.apiUrl}/orders`)}getWhatsAppShareMessage(t){return`Check out this handmade piece from Crochus!

${t.name}
Price: INR ${t.price}

${o.siteUrl}/product/${t.slug}`}static{this.\u0275fac=function(n){return new(n||r)}}static{this.\u0275prov=p({token:r,factory:r.\u0275fac,providedIn:"root"})}}return r})();export{I as a};
