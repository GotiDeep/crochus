var r={production:!0,apiUrl:"/api/v1",cloudinaryUrl:"https://res.cloudinary.com/crochus",siteUrl:"https://crochus.com"};export{r as a};
